/**
 * Главный контроллер приложения «Локальный тренажёр слепой печати»
 * Управляет экранами, прогрессом учеников, набором текста, статистикой и режимами
 */

class TypingApp {
  constructor() {
    this.courseData = window.COURSE_DATA || { sections: [] };
    this.currentStudent = 'Ученик 1';
    this.allStudents = ['Ученик 1'];
    this.progress = {}; // { studentName: { lessonNumber: { stars, wpm, cpm, accuracy, completed, date } } }
    this.teacherMode = false; // Разблокировать все уроки
    this.currentLesson = null;
    this.currentText = '';
    this.currentIndex = 0;
    this.errorsCount = 0;
    this.totalTyped = 0;
    this.startTime = null;
    this.timerInterval = null;
    this.isLessonRunning = false;
    this.fontSize = 28; // px
    this.balloonGame = null;

    this.initStorage();
    this.initDOM();
    this.initKeyboard();
    this.initEventListeners();
    this.renderCourseMap();
    this.updateStudentHeader();
  }

  /* ================= Хранилище (LocalStorage) ================= */
  initStorage() {
    try {
      const savedStudent = localStorage.getItem('typing_current_student');
      if (savedStudent) this.currentStudent = savedStudent;

      const savedStudentsList = localStorage.getItem('typing_students_list');
      if (savedStudentsList) this.allStudents = JSON.parse(savedStudentsList);
      if (!this.allStudents.includes(this.currentStudent)) {
        this.allStudents.push(this.currentStudent);
      }

      const savedProgress = localStorage.getItem('typing_progress_data');
      if (savedProgress) this.progress = JSON.parse(savedProgress);
      if (!this.progress[this.currentStudent]) {
        this.progress[this.currentStudent] = {};
      }

      const savedTeacher = localStorage.getItem('typing_teacher_mode');
      if (savedTeacher !== null) this.teacherMode = savedTeacher === 'true';

      const savedFontSize = localStorage.getItem('typing_font_size');
      if (savedFontSize) this.fontSize = parseInt(savedFontSize, 10);
    } catch (e) {
      console.warn('LocalStorage error:', e);
    }
  }

  saveStorage() {
    try {
      localStorage.setItem('typing_current_student', this.currentStudent);
      localStorage.setItem('typing_students_list', JSON.stringify(this.allStudents));
      localStorage.setItem('typing_progress_data', JSON.stringify(this.progress));
      localStorage.setItem('typing_teacher_mode', String(this.teacherMode));
      localStorage.setItem('typing_font_size', String(this.fontSize));
    } catch (e) {
      console.warn('LocalStorage save error:', e);
    }
  }

  getStudentProgress(student = this.currentStudent) {
    if (!this.progress[student]) this.progress[student] = {};
    return this.progress[student];
  }

  isLessonUnlocked(lessonNumber) {
    if (this.teacherMode) return true;
    if (lessonNumber === 1 || lessonNumber === 2) return true;
    const prog = this.getStudentProgress();
    // Урок открыт, если предыдущий урок пройден хотя бы на 1 звезду
    const prev = prog[lessonNumber - 1];
    return !!(prev && prev.completed);
  }

  /* ================= Инициализация DOM ================= */
  initDOM() {
    this.viewMap = document.getElementById('view-map');
    this.viewLesson = document.getElementById('view-lesson');
    this.viewGame = document.getElementById('view-game');
    this.viewCustom = document.getElementById('view-custom');

    this.textDisplayEl = document.getElementById('text-display');
    this.statWpmEl = document.getElementById('stat-wpm');
    this.statCpmEl = document.getElementById('stat-cpm');
    this.statAccEl = document.getElementById('stat-acc');
    this.statErrorsEl = document.getElementById('stat-errors');
    this.statTimeEl = document.getElementById('stat-time');

    this.lessonTitleEl = document.getElementById('lesson-header-title');
    this.lessonSectionEl = document.getElementById('lesson-header-section');
    this.langAlertEl = document.getElementById('lang-alert');

    // Модальные окна
    this.modalIntro = document.getElementById('modal-intro');
    this.modalResults = document.getElementById('modal-results');
    this.modalTheory = document.getElementById('modal-theory');
    this.modalSettings = document.getElementById('modal-settings');
  }

  initKeyboard() {
    const kbContainer = document.getElementById('keyboard-container');
    const handsContainer = document.getElementById('hands-container');
    this.keyboardManager = new VirtualKeyboardManager(kbContainer, handsContainer);
  }

  /* ================= Обработчики событий ================= */
  initEventListeners() {
    // Глобальный перехват клавиатуры
    window.addEventListener('keydown', (e) => this.handleGlobalKeyDown(e));

    // Навигация
    document.getElementById('btn-nav-map').addEventListener('click', () => this.showScreen('map'));
    document.getElementById('btn-lesson-back').addEventListener('click', () => this.showScreen('map'));
    document.getElementById('btn-lesson-restart').addEventListener('click', () => this.restartLesson());

    // Переключение профиля ученика
    document.getElementById('student-select').addEventListener('change', (e) => {
      this.switchStudent(e.target.value);
    });

    document.getElementById('btn-add-student').addEventListener('click', () => {
      this.promptAddStudent();
    });

    // Настройки и режим учителя
    document.getElementById('btn-settings').addEventListener('click', () => {
      this.openSettingsModal();
    });

    document.getElementById('btn-custom-text').addEventListener('click', () => {
      this.showScreen('custom');
    });

    document.getElementById('btn-start-custom').addEventListener('click', () => {
      this.startCustomText();
    });

    // Звук
    const btnMute = document.getElementById('btn-mute');
    if (btnMute) {
      btnMute.addEventListener('click', () => {
        const isMuted = !window.sound.muted;
        window.sound.setMuted(isMuted);
        btnMute.textContent = isMuted ? '🔇' : '🔊';
        btnMute.title = isMuted ? 'Включить звук' : 'Выключить звук';
      });
    }

    // Изменение размера шрифта
    document.getElementById('btn-font-plus').addEventListener('click', () => {
      this.fontSize = Math.min(46, this.fontSize + 2);
      this.applyFontSize();
    });
    document.getElementById('btn-font-minus').addEventListener('click', () => {
      this.fontSize = Math.max(18, this.fontSize - 2);
      this.applyFontSize();
    });

    // Кнопки результатов
    document.getElementById('btn-results-next').addEventListener('click', () => {
      this.closeModal(this.modalResults);
      this.goToNextLesson();
    });
    document.getElementById('btn-results-retry').addEventListener('click', () => {
      this.closeModal(this.modalResults);
      this.restartLesson();
    });
    document.getElementById('btn-results-map').addEventListener('click', () => {
      this.closeModal(this.modalResults);
      this.showScreen('map');
    });
  }

  applyFontSize() {
    if (this.textDisplayEl) {
      this.textDisplayEl.style.fontSize = `${this.fontSize}px`;
    }
    this.saveStorage();
  }

  /* ================= Управление экранами ================= */
  showScreen(screenName) {
    if (this.balloonGame) {
      this.balloonGame.stop();
    }
    this.stopTimer();
    this.isLessonRunning = false;

    this.viewMap.classList.toggle('hidden', screenName !== 'map');
    this.viewLesson.classList.toggle('hidden', screenName !== 'lesson');
    this.viewGame.classList.toggle('hidden', screenName !== 'game');
    this.viewCustom.classList.toggle('hidden', screenName !== 'custom');

    if (screenName === 'map') {
      this.renderCourseMap();
      window.scrollTo(0, 0);
    }
  }

  /* ================= Переключение учеников ================= */
  updateStudentHeader() {
    const select = document.getElementById('student-select');
    if (!select) return;
    select.innerHTML = '';
    this.allStudents.forEach(st => {
      const opt = document.createElement('option');
      opt.value = st;
      opt.textContent = st;
      if (st === this.currentStudent) opt.selected = true;
      select.appendChild(opt);
    });

    // Обновляем статистику в хедере
    const prog = this.getStudentProgress();
    let totalStars = 0;
    let completedCount = 0;
    Object.values(prog).forEach(p => {
      if (p.completed) {
        completedCount++;
        totalStars += p.stars || 0;
      }
    });

    const headerStarsEl = document.getElementById('header-stars-count');
    const headerProgEl = document.getElementById('header-progress-count');
    if (headerStarsEl) headerStarsEl.textContent = totalStars;
    if (headerProgEl) headerProgEl.textContent = `${completedCount} / ${this.courseData.totalLessons || 489}`;
  }

  switchStudent(newStudent) {
    this.currentStudent = newStudent;
    if (!this.progress[newStudent]) this.progress[newStudent] = {};
    this.saveStorage();
    this.updateStudentHeader();
    this.renderCourseMap();
  }

  promptAddStudent() {
    const name = prompt('Введите имя или фамилию нового ученика:');
    if (name && name.trim()) {
      const clean = name.trim();
      if (!this.allStudents.includes(clean)) {
        this.allStudents.push(clean);
      }
      this.switchStudent(clean);
    }
  }

  /* ================= Отрисовка карты курса (Course Map) ================= */
  renderCourseMap() {
    const container = document.getElementById('course-sections-container');
    if (!container) return;
    container.innerHTML = '';

    const studentProg = this.getStudentProgress();

    this.courseData.sections.forEach((sec, secIdx) => {
      const secCard = document.createElement('div');
      secCard.className = 'section-card';

      // Заголовок раздела со статистикой
      let secStars = 0;
      let secDone = 0;
      sec.lessons.forEach(l => {
        const lp = studentProg[l.lessonNumber];
        if (lp && lp.completed) {
          secDone++;
          secStars += lp.stars || 0;
        }
      });

      const secHeader = document.createElement('div');
      secHeader.className = 'section-header';
      secHeader.innerHTML = `
        <div class="section-title-wrap">
          <span class="section-badge">${secIdx + 1}</span>
          <h2 class="section-title">${sec.title}</h2>
        </div>
        <div class="section-meta">
          <span class="meta-item">⭐ ${secStars}</span>
          <span class="meta-item">✔️ ${secDone} / ${sec.lessons.length}</span>
        </div>
      `;

      // Сетка уроков
      const grid = document.createElement('div');
      grid.className = 'lessons-grid';

      sec.lessons.forEach(les => {
        const isUnlocked = this.isLessonUnlocked(les.lessonNumber);
        const lProg = studentProg[les.lessonNumber];
        const isDone = lProg && lProg.completed;
        const stars = (lProg && lProg.stars) || 0;

        const tile = document.createElement('div');
        tile.className = `lesson-tile ${isUnlocked ? 'unlocked' : 'locked'} ${isDone ? 'completed' : ''} type-${les.type}`;
        tile.dataset.lessonNumber = les.lessonNumber;

        let icon = '⌨️';
        if (les.type === 'game') icon = '🎈';
        if (les.type === 'theory') icon = '💡';

        let starsHtml = '';
        for (let s = 1; s <= 5; s++) {
          starsHtml += `<span class="star-mini ${s <= stars ? 'active' : ''}">★</span>`;
        }

        tile.innerHTML = `
          <div class="tile-top">
            <span class="tile-num">#${les.lessonNumber}</span>
            <span class="tile-icon">${icon}</span>
          </div>
          <div class="tile-title" title="${les.title}">${les.title}</div>
          <div class="tile-stars">${starsHtml}</div>
          ${!isUnlocked ? '<div class="tile-lock">🔒</div>' : ''}
          ${isDone && lProg.wpm ? `<div class="tile-wpm">${lProg.wpm} СВМ</div>` : ''}
        `;

        if (isUnlocked) {
          tile.addEventListener('click', () => this.openLesson(les));
        }

        grid.appendChild(tile);
      });

      secCard.appendChild(secHeader);
      secCard.appendChild(grid);
      container.appendChild(secCard);
    });
  }

  /* ================= Открытие урока ================= */
  openLesson(lesson) {
    this.currentLesson = lesson;

    // 1. Если это теоретический урок (осанка, гимнастика для глаз и т.д.)
    if (lesson.type === 'theory') {
      this.openTheoryModal(lesson);
      return;
    }

    // 2. Если у урока есть вводная инструкция по новым клавишам
    if (lesson.instructions && lesson.instructions.length > 0) {
      this.openIntroModal(lesson);
      return;
    }

    // 3. Если это игровая активность
    if (lesson.type === 'game') {
      this.startLessonGame(lesson);
      return;
    }

    // 4. Обычный урок печати
    this.startTypingLesson(lesson);
  }

  startTypingLesson(lesson) {
    this.currentLesson = lesson;
    this.showScreen('lesson');

    this.lessonTitleEl.textContent = `#${lesson.lessonNumber}: ${lesson.title}`;
    this.lessonSectionEl.textContent = lesson.sectionTitle || 'В стране клавиш';

    // Выбираем текст упражнения (text1 или случайный вариант, если их несколько)
    const texts = lesson.texts && lesson.texts.length > 0 ? lesson.texts : [''];
    this.currentText = texts[Math.floor(Math.random() * texts.length)].trim();

    this.currentIndex = 0;
    this.errorsCount = 0;
    this.totalTyped = 0;
    this.startTime = null;
    this.isLessonRunning = true;
    this.stopTimer();

    this.renderTextDisplay();
    this.applyFontSize();
    this.updateStatsDisplay();
    this.hideLangAlert();

    // Подсвечиваем первую клавишу
    if (this.currentText.length > 0) {
      this.keyboardManager.highlightChar(this.currentText[0]);
    }
  }

  restartLesson() {
    if (this.currentLesson) {
      if (this.currentLesson.type === 'game') {
        this.startLessonGame(this.currentLesson);
      } else {
        this.startTypingLesson(this.currentLesson);
      }
    }
  }

  /* ================= Отображение текста урока ================= */
  renderTextDisplay() {
    this.textDisplayEl.innerHTML = '';
    const frag = document.createDocumentFragment();

    for (let i = 0; i < this.currentText.length; i++) {
      const char = this.currentText[i];
      const span = document.createElement('span');
      span.className = 'char';
      span.id = `char-${i}`;

      if (char === ' ') {
        span.classList.add('char-space');
        span.innerHTML = '&nbsp;';
      } else if (char === '\n') {
        span.classList.add('char-newline');
        span.innerHTML = '↵<br>';
      } else {
        span.textContent = char;
      }

      if (i === this.currentIndex) {
        span.classList.add('current');
      }

      frag.appendChild(span);
    }

    this.textDisplayEl.appendChild(frag);
    this.scrollCursorIntoView();
  }

  updateCharStatus(index, status) {
    const span = document.getElementById(`char-${index}`);
    if (span) {
      span.classList.remove('current', 'correct', 'error');
      if (status) span.classList.add(status);
    }
  }

  setCursor(newIndex) {
    if (this.currentIndex < this.currentText.length) {
      const prevSpan = document.getElementById(`char-${this.currentIndex}`);
      if (prevSpan) prevSpan.classList.remove('current');
    }

    this.currentIndex = newIndex;

    if (this.currentIndex < this.currentText.length) {
      const currSpan = document.getElementById(`char-${this.currentIndex}`);
      if (currSpan) currSpan.classList.add('current');
      this.keyboardManager.highlightChar(this.currentText[this.currentIndex]);
      this.scrollCursorIntoView();
    } else {
      this.keyboardManager.clearHighlights();
    }
  }

  scrollCursorIntoView() {
    const currSpan = document.getElementById(`char-${this.currentIndex}`);
    if (currSpan) {
      const container = this.textDisplayEl;
      const offsetTop = currSpan.offsetTop - container.offsetTop;
      if (offsetTop > container.clientHeight - 80 || offsetTop < container.scrollTop) {
        container.scrollTop = offsetTop - 40;
      }
    }
  }

  /* ================= Обработка ввода с клавиатуры ================= */
  handleGlobalKeyDown(e) {
    // Если открыты модальные окна, клавиатура не печатает в уроке
    if (this.isAnyModalOpen()) {
      if (e.key === 'Escape') this.closeAllModals();
      if (e.key === 'Enter' || e.code === 'Space') {
        // Подтверждение модалки интро
        const btnIntroStart = document.getElementById('btn-intro-start');
        if (btnIntroStart && !this.modalIntro.classList.contains('hidden')) {
          btnIntroStart.click();
        }
      }
      return;
    }

    // Если игра активна
    if (this.balloonGame && this.balloonGame.running) {
      if (e.key.length === 1) {
        this.balloonGame.handleKey(e.key);
      }
      return;
    }

    // Если урок печати активен
    if (!this.isLessonRunning || !this.currentLesson) return;

    // Игнорируем клавиши-модификаторы без полезного ввода
    if (['Shift', 'Control', 'Alt', 'Meta', 'CapsLock', 'Tab'].includes(e.key)) {
      return;
    }

    // Предотвращаем дефолтный скролл страницы пробелом
    if (e.code === 'Space') {
      e.preventDefault();
    }

    // Backspace: стереть предыдущий символ
    if (e.key === 'Backspace') {
      e.preventDefault();
      if (this.currentIndex > 0) {
        this.updateCharStatus(this.currentIndex, '');
        this.setCursor(this.currentIndex - 1);
        this.updateCharStatus(this.currentIndex, 'current');
      }
      return;
    }

    // Запуск таймера при первом нажатии
    if (!this.startTime) {
      this.startTime = performance.now();
      this.startTimer();
    }

    const expectedChar = this.currentText[this.currentIndex];
    let typedChar = e.key;

    // Проверка английской раскладки
    if (window.EN_TO_RU_MAP[typedChar] && expectedChar !== typedChar) {
      const mapped = window.EN_TO_RU_MAP[typedChar];
      if (mapped === expectedChar) {
        // Ученик нажал правильную физическую клавишу, но на английской раскладке!
        this.showLangAlert();
      }
    }

    this.totalTyped++;
    const isCorrect = typedChar === expectedChar;

    // Анимация нажатия на виртуальной клавиатуре
    this.keyboardManager.flashKeyPress(e.code, isCorrect);

    if (isCorrect) {
      if (window.sound) window.sound.playKeyClick();
      this.updateCharStatus(this.currentIndex, 'correct');
      this.hideLangAlert();
      this.setCursor(this.currentIndex + 1);

      // Проверка окончания урока
      if (this.currentIndex >= this.currentText.length) {
        this.completeTypingLesson();
      }
    } else {
      if (window.sound) window.sound.playError();
      this.errorsCount++;
      this.updateCharStatus(this.currentIndex, 'error');
      // В режиме исправления ошибок требуем нажать правильную клавишу или Backspace
    }

    this.updateStatsDisplay();
  }

  showLangAlert() {
    if (this.langAlertEl) this.langAlertEl.classList.remove('hidden');
  }

  hideLangAlert() {
    if (this.langAlertEl) this.langAlertEl.classList.add('hidden');
  }

  /* ================= Статистика и Таймер ================= */
  startTimer() {
    this.stopTimer();
    this.timerInterval = setInterval(() => {
      this.updateStatsDisplay();
    }, 500);
  }

  stopTimer() {
    if (this.timerInterval) {
      clearInterval(this.timerInterval);
      this.timerInterval = null;
    }
  }

  updateStatsDisplay() {
    const elapsedSecs = this.startTime ? Math.max(0.5, (performance.now() - this.startTime) / 1000) : 0;
    const mins = elapsedSecs / 60;

    // CPM (Знаков в минуту) и WPM (Слов в минуту = CPM / 5)
    const cpm = mins > 0 ? Math.round(this.currentIndex / mins) : 0;
    const wpm = Math.round(cpm / 5);

    // Точность (%)
    let acc = 100;
    if (this.totalTyped > 0) {
      acc = Math.max(0, Math.round(((this.totalTyped - this.errorsCount) / this.totalTyped) * 100));
    }

    if (this.statWpmEl) this.statWpmEl.textContent = wpm;
    if (this.statCpmEl) this.statCpmEl.textContent = cpm;
    if (this.statAccEl) this.statAccEl.textContent = `${acc}%`;
    if (this.statErrorsEl) this.statErrorsEl.textContent = this.errorsCount;

    // Таймер
    const m = Math.floor(elapsedSecs / 60).toString().padStart(2, '0');
    const s = Math.floor(elapsedSecs % 60).toString().padStart(2, '0');
    if (this.statTimeEl) this.statTimeEl.textContent = `${m}:${s}`;
  }

  /* ================= Завершение урока печати ================= */
  completeTypingLesson() {
    this.stopTimer();
    this.isLessonRunning = false;

    const elapsedSecs = Math.max(1, (performance.now() - this.startTime) / 1000);
    const mins = elapsedSecs / 60;
    const cpm = Math.round(this.currentText.length / mins);
    const wpm = Math.round(cpm / 5);
    const acc = this.totalTyped > 0 ? Math.max(0, Math.round(((this.totalTyped - this.errorsCount) / this.totalTyped) * 100)) : 100;

    // Расчет звёзд (от 1 до 5)
    // 5 звезд: Точность >= 98% и скорость >= goalWpm
    // 4 звезды: Точность >= 95% и скорость >= minWpm
    // 3 звезды: Точность >= 90%
    // 2 звезды: Точность >= 80%
    // 1 звезда: урок завершен
    const goalWpm = this.currentLesson.goalWpm || 15;
    const minWpm = this.currentLesson.minWpm || 10;
    const minAcc = this.currentLesson.minAccuracy || 80;

    let stars = 1;
    if (acc >= 98 && wpm >= goalWpm) stars = 5;
    else if (acc >= 95 && wpm >= minWpm) stars = 4;
    else if (acc >= 90) stars = 3;
    else if (acc >= minAcc) stars = 2;
    else stars = 1;

    // Сохраняем прогресс ученика (только лучший результат)
    const prog = this.getStudentProgress();
    const prev = prog[this.currentLesson.lessonNumber] || {};
    const bestStars = Math.max(prev.stars || 0, stars);
    const bestWpm = Math.max(prev.wpm || 0, wpm);

    prog[this.currentLesson.lessonNumber] = {
      completed: true,
      stars: bestStars,
      wpm: bestWpm,
      cpm: Math.max(prev.cpm || 0, cpm),
      accuracy: Math.max(prev.accuracy || 0, acc),
      lastDate: new Date().toISOString()
    };
    this.saveStorage();
    this.updateStudentHeader();

    // Звуки победы
    if (window.sound) {
      window.sound.playVictoryFanfare();
      setTimeout(() => {
        for (let i = 0; i < stars; i++) {
          setTimeout(() => window.sound.playStarChime(i), i * 220);
        }
      }, 500);
    }

    // Открываем модальное окно результатов
    this.openResultsModal({
      lesson: this.currentLesson,
      wpm: wpm,
      cpm: cpm,
      acc: acc,
      errors: this.errorsCount,
      stars: stars,
      time: `${Math.floor(elapsedSecs / 60)}:${Math.floor(elapsedSecs % 60).toString().padStart(2, '0')}`
    });
  }

  /* ================= Модальные окна ================= */
  openResultsModal(data) {
    document.getElementById('res-lesson-title').textContent = `#${data.lesson.lessonNumber}: ${data.lesson.title}`;
    document.getElementById('res-wpm').textContent = data.wpm;
    document.getElementById('res-cpm').textContent = data.cpm;
    document.getElementById('res-acc').textContent = `${data.acc}%`;
    document.getElementById('res-errors').textContent = data.errors;
    document.getElementById('res-time').textContent = data.time;

    // Звезды
    const starsContainer = document.getElementById('res-stars');
    starsContainer.innerHTML = '';
    for (let i = 1; i <= 5; i++) {
      const s = document.createElement('span');
      s.className = `star-big ${i <= data.stars ? 'star-earned' : ''}`;
      s.textContent = '★';
      s.style.animationDelay = `${i * 0.15}s`;
      starsContainer.appendChild(s);
    }

    // Сообщение-похвала для детей
    const messageEl = document.getElementById('res-praise-message');
    const praises = [
      'Молодец! Прекрасная работа!',
      'Великолепно! Твои пальцы летают по клавишам!',
      'Отличная точность! Так держать!',
      'Ты делаешь огромные успехи в слепой печати!'
    ];
    if (messageEl) {
      messageEl.textContent = praises[Math.floor(Math.random() * praises.length)];
    }

    this.openModal(this.modalResults);
  }

  goToNextLesson() {
    if (!this.currentLesson) {
      this.showScreen('map');
      return;
    }
    const nextNum = this.currentLesson.lessonNumber + 1;
    let nextLesson = null;

    for (const sec of this.courseData.sections) {
      nextLesson = sec.lessons.find(l => l.lessonNumber === nextNum);
      if (nextLesson) break;
    }

    if (nextLesson && this.isLessonUnlocked(nextNum)) {
      this.openLesson(nextLesson);
    } else {
      this.showScreen('map');
    }
  }

  /* ================= Вводные слайды урока (Instructions) ================= */
  openIntroModal(lesson) {
    const slides = lesson.instructions || [];
    let currentSlide = 0;

    const renderSlide = () => {
      const slide = slides[currentSlide];
      document.getElementById('intro-title').textContent = slide.title || lesson.title;
      document.getElementById('intro-tag').textContent = slide.tag || `Урок #${lesson.lessonNumber}`;
      document.getElementById('intro-body').textContent = slide.body || '';

      const charBox = document.getElementById('intro-chr-box');
      if (slide.chr) {
        charBox.style.display = 'flex';
        charBox.textContent = slide.chr;
      } else {
        charBox.style.display = 'none';
      }

      document.getElementById('intro-step-counter').textContent = `Шаг ${currentSlide + 1} из ${slides.length}`;
      document.getElementById('btn-intro-prev').style.display = currentSlide > 0 ? 'inline-block' : 'none';
      
      const isLast = currentSlide === slides.length - 1;
      document.getElementById('btn-intro-next').style.display = !isLast ? 'inline-block' : 'none';
      document.getElementById('btn-intro-start').style.display = isLast ? 'inline-block' : 'none';
    };

    document.getElementById('btn-intro-next').onclick = () => {
      if (currentSlide < slides.length - 1) {
        currentSlide++;
        renderSlide();
      }
    };
    document.getElementById('btn-intro-prev').onclick = () => {
      if (currentSlide > 0) {
        currentSlide--;
        renderSlide();
      }
    };
    document.getElementById('btn-intro-start').onclick = () => {
      this.closeModal(this.modalIntro);
      if (lesson.type === 'game') {
        this.startLessonGame(lesson);
      } else {
        this.startTypingLesson(lesson);
      }
    };

    renderSlide();
    this.openModal(this.modalIntro);
  }

  /* ================= Теоретические уроки (Осанка, глаза, финал) ================= */
  openTheoryModal(lesson) {
    const titleEl = document.getElementById('theory-title');
    const bodyEl = document.getElementById('theory-content');

    titleEl.textContent = `#${lesson.lessonNumber}: ${lesson.title}`;

    if (lesson.lessonNumber === 1 || lesson.lessonNumber === 2) {
      bodyEl.innerHTML = `
        <div class="theory-article">
          <div class="video-container">
            <video controls autoplay class="lesson-video" src="videos/lesson_2.mp4">
              Ваш браузер не поддерживает видео.
            </video>
          </div>
          <h3>Правильная посадка и опорный ряд</h3>
          <p>Добро пожаловать в курс <strong>«В стране клавиш»</strong>! Чтобы печатать быстро и не уставать, запомни главные правила:</p>
          <ul class="theory-list">
            <li><strong>Спина:</strong> сиди прямо, опираясь на спинку стула. Не сутулься!</li>
            <li><strong>Руки:</strong> локти согнуты под углом 90 градусов, кисти свободно парят над клавиатурой.</li>
            <li><strong>Опорный ряд:</strong> указательные пальцы всегда лежат на клавишах <strong>[А]</strong> и <strong>[О]</strong>. На них есть специальные рельефные засечки — нащупай их пальцами!</li>
            <li><strong>Золотое правило:</strong> никогда не подглядывай на клавиатуру! Виртуальные подсказки на экране подскажут, каким пальцем нажимать букву.</li>
          </ul>
        </div>
      `;
    } else if (lesson.lessonNumber === 29 || lesson.lessonNumber === 31) {
      bodyEl.innerHTML = `
        <div class="theory-article">
          <div class="video-container">
            <video controls autoplay class="lesson-video" src="videos/lesson_31.mp4">
              Ваш браузер не поддерживает видео.
            </video>
          </div>
          <h3>Сиди прямо, будешь здоров!</h3>
          <p>Эргономика рабочего места помогает сохранить осанку и острое зрение на всю жизнь:</p>
          <ul class="theory-list">
            <li><strong>Расстояние до монитора:</strong> держи экран на расстоянии вытянутой руки (50–70 см).</li>
            <li><strong>Уровень глаз:</strong> верхний край экрана должен быть на уровне глаз или чуть ниже.</li>
            <li><strong>Ступни:</strong> должны полностью стоять на полу, а не висеть в воздухе.</li>
            <li><strong>Плечи:</strong> расслаблены, не поднимай плечи вверх во время набора текста.</li>
          </ul>
        </div>
      `;
    } else if (lesson.lessonNumber === 81 || lesson.lessonNumber === 84) {
      bodyEl.innerHTML = `
        <div class="theory-article">
          <div class="video-container">
            <video controls autoplay class="lesson-video" src="videos/lesson_84.mp4">
              Ваш браузер не поддерживает видео.
            </video>
          </div>
          <h3>Сделай перерыв и гимнастику!</h3>
          <p>Каждые 20-30 минут печати полезно делать маленькую разминку:</p>
          <ul class="theory-list">
            <li><strong>Правило 20-20-20:</strong> каждые 20 минут посмотри на 20 секунд вдаль в окно.</li>
            <li><strong>Гимнастика для глаз:</strong> поморгай, затем медленно опиши глазами круг и восьмёрку.</li>
            <li><strong>Встряхни кисти:</strong> расслабь руки, сжимай и разжимай кулаки 10 раз.</li>
            <li><strong>Потянись:</strong> подними руки вверх и сделай глубокий вдох!</li>
          </ul>
        </div>
      `;
    } else {
      bodyEl.innerHTML = `
        <div class="theory-article certificate-view">
          <div class="theory-illustration">🎓 🏆 🌟</div>
          <h3>Поздравляем с окончанием курса!</h3>
          <p>Ты прошёл все уроки программы <strong>«В стране клавиш»</strong> и освоил полноценный слепой десятипальцевый метод печати!</p>
          <p>Теперь твои пальцы знают расположение каждой русской буквы, цифры и знака препинания без необходимости смотреть на клавиатуру.</p>
          <div class="diploma-badge">Мастер слепой печати: <strong>${this.currentStudent}</strong></div>
        </div>
      `;
    }

    document.getElementById('btn-theory-done').onclick = () => {
      const vid = bodyEl.querySelector('video');
      if (vid) vid.pause();
      this.closeModal(this.modalTheory);
      // Засчитываем прохождение
      const prog = this.getStudentProgress();
      prog[lesson.lessonNumber] = {
        completed: true,
        stars: 5,
        wpm: 25,
        cpm: 125,
        accuracy: 100,
        lastDate: new Date().toISOString()
      };
      this.saveStorage();
      this.updateStudentHeader();
      this.goToNextLesson();
    };

    this.openModal(this.modalTheory);
  }

  /* ================= Режим игры «Воздушные шарики» ================= */
  startLessonGame(lesson) {
    this.currentLesson = lesson;
    this.showScreen('game');

    const gameContainer = document.getElementById('balloon-game-container');
    const texts = lesson.texts && lesson.texts.length > 0 ? lesson.texts : [''];
    const gameText = texts[0];

    this.balloonGame = new BalloonGame(gameContainer, (res) => {
      if (res.cancelled) {
        this.showScreen('map');
        return;
      }

      if (res.success) {
        const prog = this.getStudentProgress();
        prog[lesson.lessonNumber] = {
          completed: true,
          stars: 5,
          wpm: lesson.goalWpm || 20,
          cpm: (lesson.goalWpm || 20) * 5,
          accuracy: 95,
          lastDate: new Date().toISOString()
        };
        this.saveStorage();
        this.updateStudentHeader();

        this.openResultsModal({
          lesson: lesson,
          wpm: lesson.goalWpm || 20,
          cpm: (lesson.goalWpm || 20) * 5,
          acc: 95,
          errors: res.missed,
          stars: 5,
          time: 'Игра'
        });
      } else {
        alert('Шарики улетели! Попробуй еще раз.');
        this.startLessonGame(lesson);
      }
    });

    this.balloonGame.start(gameText, { goalWpm: lesson.goalWpm || 15 });
  }

  /* ================= Свой текст / Конструктор урока ================= */
  startCustomText() {
    const input = document.getElementById('custom-text-input');
    const val = input ? input.value.trim() : '';
    if (!val) {
      alert('Пожалуйста, введите текст для тренировки!');
      return;
    }

    const customLesson = {
      lessonNumber: 999,
      title: 'Свой текст / Диктант учителя',
      sectionTitle: 'Пользовательский урок',
      type: 'typing',
      texts: [val],
      goalWpm: 20,
      minWpm: 12,
      minAccuracy: 85
    };

    this.startTypingLesson(customLesson);
  }

  /* ================= Настройки и Экспорт/Импорт ================= */
  openSettingsModal() {
    const chkUnlock = document.getElementById('chk-teacher-unlock');
    if (chkUnlock) chkUnlock.checked = this.teacherMode;

    chkUnlock.onchange = (e) => {
      this.teacherMode = e.target.checked;
      this.saveStorage();
      this.renderCourseMap();
    };

    document.getElementById('btn-export-progress').onclick = () => {
      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify({
        students: this.allStudents,
        progress: this.progress,
        exportDate: new Date().toISOString()
      }, null, 2));
      const dlAnchor = document.createElement('a');
      dlAnchor.setAttribute('href', dataStr);
      dlAnchor.setAttribute('download', `прогресс_слепая_печать_${this.currentStudent}.json`);
      dlAnchor.click();
    };

    document.getElementById('input-import-file').onchange = (e) => {
      const file = e.target.files[0];
      if (!file) return;
      const reader = new FileReader();
      reader.onload = (evt) => {
        try {
          const parsed = JSON.parse(evt.target.result);
          if (parsed.progress) {
            this.progress = parsed.progress;
            if (parsed.students) this.allStudents = parsed.students;
            this.saveStorage();
            this.updateStudentHeader();
            this.renderCourseMap();
            alert('Прогресс успешно загружен!');
            this.closeModal(this.modalSettings);
          }
        } catch (err) {
          alert('Ошибка при чтении файла: ' + err.message);
        }
      };
      reader.readAsText(file);
    };

    document.getElementById('btn-reset-current-progress').onclick = () => {
      if (confirm(`Вы уверены, что хотите сбросить прогресс для ученика "${this.currentStudent}"?`)) {
        this.progress[this.currentStudent] = {};
        this.saveStorage();
        this.updateStudentHeader();
        this.renderCourseMap();
        alert('Прогресс сброшен!');
        this.closeModal(this.modalSettings);
      }
    };

    document.getElementById('btn-settings-close').onclick = () => {
      this.closeModal(this.modalSettings);
    };

    this.openModal(this.modalSettings);
  }

  /* ================= Вспомогательные функции модалок ================= */
  openModal(modal) {
    if (modal) modal.classList.remove('hidden');
  }

  closeModal(modal) {
    if (modal) modal.classList.add('hidden');
  }

  closeAllModals() {
    [this.modalIntro, this.modalResults, this.modalTheory, this.modalSettings].forEach(m => {
      if (m) m.classList.add('hidden');
    });
  }

  isAnyModalOpen() {
    return [this.modalIntro, this.modalResults, this.modalTheory, this.modalSettings].some(m => m && !m.classList.contains('hidden'));
  }
}

// Запуск приложения при загрузке страницы
window.addEventListener('DOMContentLoaded', () => {
  window.typingApp = new TypingApp();
});
