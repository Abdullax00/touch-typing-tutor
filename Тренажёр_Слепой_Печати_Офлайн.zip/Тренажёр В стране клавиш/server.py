#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Локальный сервер тренажёра слепой печати «В стране клавиш»
Позволяет открыть тренажёр для всего компьютерного класса по локальной сети Wi-Fi/LAN
"""

import http.server
import socketserver
import socket
import webbrowser
import os
import sys

PORT = 8080

def get_local_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"

class CustomHandler(http.server.SimpleHTTPRequestHandler):
    def end_headers(self):
        # Отключаем кэширование при локальной разработке
        self.send_header('Cache-Control', 'no-store, no-cache, must-revalidate')
        super().end_headers()

def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    local_ip = get_local_ip()
    local_url = f"http://localhost:{PORT}"
    lan_url = f"http://{local_ip}:{PORT}"

    print("=" * 65)
    print("  ⌨️  ЛОКАЛЬНЫЙ ТРЕНАЖЁР СЛЕПОЙ ПЕЧАТИ «В СТРАНЕ КЛАВИШ»")
    print("=" * 65)
    print(f"Сервер успешно запущен!\n")
    print(f"👉 На этом компьютере:          {local_url}")
    print(f"👉 Для компьютеров учеников в классе:")
    print(f"   Откройте на компьютерах детей адрес: {lan_url}\n")
    print("Чтобы остановить сервер, нажмите Ctrl + C в этом окне.")
    print("=" * 65)

    # Автоматически открываем браузер
    try:
        webbrowser.open(local_url)
    except Exception:
        pass

    socketserver.TCPServer.allow_reuse_address = True
    with socketserver.TCPServer(("", PORT), CustomHandler) as httpd:
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\nСервер остановлен.")
            sys.exit(0)

if __name__ == '__main__':
    main()
