@echo off
chcp 65001 > nul
title Локальный тренажёр слепой печати «В стране клавиш»

set "CURRENT_DIR=%~dp0"
set "HTML_FILE=%CURRENT_DIR%index.html"

echo Запуск тренажёра слепой печати «В стране клавиш»...

:: Попробуем запустить в режиме настольного приложения (App Mode) через Edge или Chrome
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="file:///%HTML_FILE:\=/%"
    exit /b
)

if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" --app="file:///%HTML_FILE:\=/%"
    exit /b
)

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="file:///%HTML_FILE:\=/%"
    exit /b
)

:: Если пути нестандартные, открываем в браузере по умолчанию
start "" "%HTML_FILE%"
exit /b
